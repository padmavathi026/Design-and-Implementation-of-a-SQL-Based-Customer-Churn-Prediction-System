INSERT INTO Customer (CustomerId, Surname, FullName, Email, GeographyId, GenderId, Age, CreatedAt) VALUES
(10001, 'Smith', 'John Smith', 'johnsmith1@example.com', 1, 1, 30, '2022-01-01'),
(10002, 'Johnson', 'Emily Johnson', 'emilyj2@example.com', 2, 2, 28, '2022-01-01'),
(10003, 'Williams', 'David Williams', 'davidw3@example.com', 3, 1, 35, '2022-01-01'),
(10004, 'Brown', 'Sarah Brown', 'sarahb4@example.com', 1, 2, 40, '2022-01-01'),
(10005, 'Jones', 'Chris Jones', 'chrisj5@example.com', 2, 1, 24, '2022-01-01'),
(10006, 'Garcia', 'Anna Garcia', 'annag6@example.com', 3, 2, 32, '2022-01-01'),
(10007, 'Miller', 'James Miller', 'jamesm7@example.com', 1, 1, 29, '2022-01-01'),
(10008, 'Davis', 'Laura Davis', 'laurad8@example.com', 2, 2, 27, '2022-01-01'),
(10009, 'Rodriguez', 'Carlos Rodriguez', 'carlosr9@example.com', 3, 1, 31, '2022-01-01'),
(10010, 'Martinez', 'Maria Martinez', 'mariam10@example.com', 1, 2, 33, '2022-01-01');

INSERT INTO LoanApplication (ApplicationId, CustomerId, LoanAmount, LoanStatus, ApplicationDate) VALUES
(1, 10001, 5000.00, 'Approved', '2024-01-01'),
(2, 10002, 7500.00, 'Pending', '2024-01-03'),
(3, 10003, 6000.00, 'Rejected', '2024-01-05'),
(4, 10004, 9000.00, 'Approved', '2024-01-06'),
(5, 10005, 3000.00, 'Pending', '2024-01-08'),
(6, 10006, 10000.00, 'Rejected', '2024-01-10'),
(7, 10007, 4000.00, 'Approved', '2024-01-11'),
(8, 10008, 8500.00, 'Pending', '2024-01-13'),
(9, 10009, 9500.00, 'Approved', '2024-01-14'),
(10, 10010, 4500.00, 'Rejected', '2024-01-16');

INSERT INTO Account (CustomerId, Tenure, Balance, NumOfProducts, AccountType, OpenDate, Status, LinkedLoanId) VALUES
(10001, 3, 12500.50, 2, 'Standard', '2020-01-01', 'Active', 1),
(10002, 5, 9800.00, 1, 'Premium', '2020-02-15', 'Active', 2),
(10003, 2, 4700.75, 2, 'Standard', '2020-03-10', 'Inactive', 3),
(10004, 4, 15800.00, 3, 'Gold', '2020-04-01', 'Active', 4),
(10005, 1, 2100.00, 1, 'Standard', '2020-05-20', 'Active', 5),
(10006, 6, 3200.00, 1, 'Standard', '2020-06-30', 'Inactive', 6),
(10007, 2, 9100.40, 2, 'Premium', '2020-07-11', 'Active', 7),
(10008, 3, 6700.00, 1, 'Standard', '2020-08-05', 'Active', 8),
(10009, 5, 10500.00, 2, 'Gold', '2020-09-18', 'Active', 9),
(10010, 4, 8700.90, 1, 'Standard', '2020-10-20', 'Inactive', 10);


INSERT INTO CreditCard (CustomerId, HasCrCard, CardType, CardLimit, LinkedAccountId) VALUES
(10001, TRUE, 'Visa', 5000.00, 1),
(10002, FALSE, 'MasterCard', 3000.00, 2),
(10003, TRUE, 'Visa', 7000.00, 3),
(10004, TRUE, 'Amex', 9000.00, 4),
(10005, FALSE, 'Visa', 5000.00, 5),
(10006, TRUE, 'Visa', 5000.00, 6),
(10007, TRUE, 'MasterCard', 4000.00, 7),
(10008, FALSE, 'Visa', 2000.00, 8),
(10009, TRUE, 'Visa', 6000.00, 9),
(10010, FALSE, 'Visa', 3000.00, 10);


INSERT INTO ActivityStatus (CustomerId, IsActive, LastLoginDate, LoginFrequency, LinkedLoanId) VALUES
(10001, TRUE, '2024-05-01', 5, 1),
(10002, FALSE, '2024-04-20', 2, 2),
(10003, TRUE, '2024-05-03', 8, 3),
(10004, TRUE, '2024-05-02', 6, 4),
(10005, FALSE, '2024-03-30', 1, 5),
(10006, TRUE, '2024-04-25', 3, 6),
(10007, TRUE, '2024-05-01', 4, 7),
(10008, FALSE, '2024-04-10', 2, 8),
(10009, TRUE, '2024-05-04', 5, 9),
(10010, TRUE, '2024-05-05', 7, 10);


INSERT INTO Salary (CustomerId, EstimatedSalary, SalaryBand, LastIncrement, LinkedAccountId) VALUES
(10001, 45000.00, 'Low', 1000.00, 1),
(10002, 80000.00, 'Medium', 1500.00, 2),
(10003, 120000.00, 'High', 2500.00, 3),
(10004, 200000.00, 'Very High', 5000.00, 4),
(10005, 30000.00, 'Low', 500.00, 5),
(10006, 95000.00, 'Medium', 1200.00, 6),
(10007, 140000.00, 'High', 2200.00, 7),
(10008, 240000.00, 'Very High', 6000.00, 8),
(10009, 48000.00, 'Low', 800.00, 9),
(10010, 70000.00, 'Medium', 1300.00, 10);


INSERT INTO ChurnStatus (CustomerId, Exited, ChurnReason, LastContactDate) VALUES
(10001, FALSE, NULL, NULL),
(10002, TRUE, 'Moved to another bank', '2024-06-01'),
(10003, FALSE, NULL, NULL),
(10004, TRUE, 'High fees', '2024-06-01'),
(10005, FALSE, NULL, NULL),
(10006, TRUE, 'Lack of support', '2024-06-01'),
(10007, FALSE, NULL, NULL),
(10008, FALSE, NULL, NULL),
(10009, TRUE, 'Better rates elsewhere', '2024-06-01'),
(10010, FALSE, NULL, NULL);


INSERT INTO CustomerLog (CustomerId, Action, ActionDate, LinkedLoanId) VALUES
(10001, 'Account Created', '2024-06-01', 1),
(10002, 'Applied for Loan', '2024-06-02', 2),
(10003, 'Loan Approved', '2024-06-03', 3),
(10004, 'Card Issued', '2024-06-04', 4),
(10005, 'Updated Address', '2024-06-05', 5),
(10006, 'Closed Account', '2024-06-06', 6),
(10007, 'Requested Statement', '2024-06-07', 7),
(10008, 'Changed Email', '2024-06-08', 8),
(10009, 'Login Issue Reported', '2024-06-09', 9),
(10010, 'Password Reset', '2024-06-10', 10);


INSERT INTO RiskScore (CustomerId, CreditScore, ScoreCategory, LinkedAccountId) VALUES
(10001, 700, 'Good', 1),
(10002, 650, 'Fair', 2),
(10003, 720, 'Good', 3),
(10004, 580, 'Poor', 4),
(10005, 790, 'Very Good', 5),
(10006, 820, 'Excellent', 6),
(10007, 680, 'Fair', 7),
(10008, 750, 'Very Good', 8),
(10009, 810, 'Excellent', 9),
(10010, 600, 'Poor', 10);


INSERT INTO StatusFlag (CustomerId, IsHighValueCustomer, IsFlaggedForReview) VALUES
(10001, TRUE, FALSE),
(10002, FALSE, FALSE),
(10003, FALSE, TRUE),
(10004, TRUE, FALSE),
(10005, FALSE, FALSE),
(10006, FALSE, TRUE),
(10007, TRUE, FALSE),
(10008, FALSE, FALSE),
(10009, TRUE, FALSE),
(10010, FALSE, FALSE);
