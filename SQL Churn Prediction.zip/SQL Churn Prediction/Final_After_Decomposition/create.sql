DROP TABLE IF EXISTS StatusFlag, RiskScore, CustomerLog, ChurnStatus, Salary, ActivityStatus, CreditCard, Account, LoanApplication, Customer CASCADE;

CREATE TABLE Customer (
    CustomerId BIGINT PRIMARY KEY,
    Surname VARCHAR(100) NOT NULL,
    FullName VARCHAR(150),
    Email VARCHAR(150) UNIQUE,
    GeographyId INT NOT NULL,
    GenderId INT NOT NULL,
    Age INT CHECK (Age >= 18),
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE LoanApplication (
    ApplicationId SERIAL PRIMARY KEY,
    CustomerId BIGINT REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    LoanAmount DECIMAL(10,2) NOT NULL,
    LoanStatus VARCHAR(20) DEFAULT 'Pending',
    ApplicationDate DATE DEFAULT CURRENT_DATE
);

CREATE TABLE Account (
    AccountId SERIAL PRIMARY KEY,
    CustomerId BIGINT REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    LinkedLoanId INT REFERENCES LoanApplication(ApplicationId) ON DELETE SET NULL,
    Tenure INT CHECK (Tenure >= 0),
    Balance DECIMAL(15, 2) DEFAULT 0.00,
    NumOfProducts INT CHECK (NumOfProducts >= 1),
    AccountType VARCHAR(30) DEFAULT 'Standard',
    OpenDate DATE DEFAULT CURRENT_DATE,
    Status VARCHAR(20) DEFAULT 'Active'
);

CREATE TABLE CreditCard (
    CustomerId BIGINT PRIMARY KEY REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    LinkedAccountId INT REFERENCES Account(AccountId) ON DELETE SET NULL,
    HasCrCard BOOLEAN DEFAULT FALSE,
    CardType VARCHAR(30) DEFAULT 'Visa',
    CardLimit DECIMAL(12, 2) DEFAULT 5000.00
);

CREATE TABLE ActivityStatus (
    CustomerId BIGINT PRIMARY KEY REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    LinkedLoanId INT REFERENCES LoanApplication(ApplicationId) ON DELETE SET NULL,
    IsActive BOOLEAN DEFAULT FALSE,
    LastLoginDate DATE,
    LoginFrequency INT DEFAULT 0
);

-- Creating SalaryBandMapping table (decomposed from Salary)
CREATE TABLE SalaryBandMapping (
    EstimatedSalary DECIMAL(15, 2) PRIMARY KEY,
    SalaryBand VARCHAR(30)
);

-- Creating SalaryDetails table (decomposed from Salary)
CREATE TABLE SalaryDetails (
    CustomerId BIGINT PRIMARY KEY REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    LinkedAccountId INT REFERENCES Account(AccountId) ON DELETE SET NULL,
    EstimatedSalary DECIMAL(15, 2) NOT NULL,
    LastIncrement DECIMAL(10, 2) DEFAULT 0.00,
    FOREIGN KEY (EstimatedSalary) REFERENCES SalaryBandMapping(EstimatedSalary) ON DELETE RESTRICT
);


CREATE TABLE ChurnStatus (
    CustomerId BIGINT PRIMARY KEY REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    Exited BOOLEAN NOT NULL,
    ChurnReason VARCHAR(255),
    LastContactDate DATE
);

-- Creating ScoreCategoryMapping table (decomposed from RiskScore)
CREATE TABLE ScoreCategoryMapping (
    CreditScore INT PRIMARY KEY CHECK (CreditScore BETWEEN 300 AND 850),
    ScoreCategory VARCHAR(50)
);

-- Creating RiskScoreDetails table (decomposed from RiskScore)
CREATE TABLE RiskScoreDetails (
    CustomerId BIGINT PRIMARY KEY REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    LinkedAccountId INT REFERENCES Account(AccountId) ON DELETE SET NULL,
    CreditScore INT CHECK (CreditScore BETWEEN 300 AND 850),
    FOREIGN KEY (CreditScore) REFERENCES ScoreCategoryMapping(CreditScore) ON DELETE RESTRICT
);

CREATE TABLE StatusFlag (
    CustomerId BIGINT PRIMARY KEY REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    IsHighValueCustomer BOOLEAN DEFAULT FALSE,
    IsFlaggedForReview BOOLEAN DEFAULT FALSE
);

CREATE TABLE CustomerLog (
    LogId SERIAL PRIMARY KEY,
    CustomerId BIGINT REFERENCES Customer(CustomerId) ON DELETE CASCADE,
    LinkedLoanId INT REFERENCES LoanApplication(ApplicationId) ON DELETE SET NULL,
    Action VARCHAR(255),
    ActionDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
