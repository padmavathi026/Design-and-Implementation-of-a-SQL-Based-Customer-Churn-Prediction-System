COPY Customer(CustomerId, Surname, GeographyId, GenderId, Age, FullName, Email, CreatedAt)
FROM '/Library/PostgreSQL/17/data/Customer.csv' DELIMITER ',' CSV HEADER;

COPY LoanApplication(ApplicationId, CustomerId, LoanAmount, LoanStatus, ApplicationDate)
FROM '/Library/PostgreSQL/17/data/LoanApplication.csv' DELIMITER ',' CSV HEADER;

COPY Account(AccountId, CustomerId, Tenure, Balance, NumOfProducts, AccountType, OpenDate, Status, LinkedLoanId)
FROM '/Library/PostgreSQL/17/data/Account.csv' DELIMITER ',' CSV HEADER;

COPY CreditCard(CustomerId, HasCrCard, CardType, CardLimit, LinkedAccountId)
FROM '/Library/PostgreSQL/17/data/CreditCard.csv' DELIMITER ',' CSV HEADER;

COPY ActivityStatus(CustomerId, IsActive, LastLoginDate, LoginFrequency, LinkedLoanId)
FROM '/Library/PostgreSQL/17/data/ActivityStatus.csv' DELIMITER ',' CSV HEADER;

COPY SalaryBandMapping(EstimatedSalary, SalaryBand)
FROM '/Library/PostgreSQL/17/data/SalaryBandMapping.csv' DELIMITER ',' CSV HEADER;
COPY SalaryDetails(CustomerId, EstimatedSalary, LastIncrement, LinkedAccountId)
FROM '/Library/PostgreSQL/17/data/SalaryDetails.csv' DELIMITER ',' CSV HEADER;

COPY ChurnStatus(CustomerId, Exited, ChurnReason, LastContactDate)
FROM '/Library/PostgreSQL/17/data/ChurnStatus.csv' DELIMITER ',' CSV HEADER;


COPY ScoreCategoryMapping(CreditScore, ScoreCategory)
FROM '/Library/PostgreSQL/17/data/ScoreCategoryMapping.csv' DELIMITER ',' CSV HEADER;
COPY RiskScoreDetails(CustomerId, CreditScore, LinkedAccountId)
FROM '/Library/PostgreSQL/17/data/RiskScoreDetails.csv' DELIMITER ',' CSV HEADER;


COPY StatusFlag(CustomerId, IsHighValueCustomer, IsFlaggedForReview)
FROM '/Library/PostgreSQL/17/data/StatusFlag.csv' DELIMITER ',' CSV HEADER;

COPY CustomerLog(LogId, CustomerId, Action, ActionDate, LinkedLoanId)
FROM '/Library/PostgreSQL/17/data/CustomerLog.csv' DELIMITER ',' CSV HEADER;

